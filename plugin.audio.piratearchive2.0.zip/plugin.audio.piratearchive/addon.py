import xbmc
import xbmcgui
import xbmcplugin
import requests
from bs4 import BeautifulSoup
import sys
import urllib.parse

BASE_URL = 'https://www.thepiratearchive.net/stations/'

def get_content(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    return soup

def get_items(url):
    soup = get_content(url)
    items = []
    for link in soup.find_all('a'):
        href = link.get('href')
        if href and href.startswith('http'):
            title = link.text.strip()
            items.append((title, href))
    return items

def list_items(url):
    items = get_items(url)
    for title, href in items:
        is_folder = not href.endswith('.mp3','.wma','.flac','.m4a','.opus','.weba','.webm','.ogg')  # Assuming audio files end with .mp3
        li = xbmcgui.ListItem(label=title)
        li.setInfo('music', {'title': title})
        if is_folder:
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'url': href}), listitem=li, isFolder=True)
        else:
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'play': href}), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def build_url(query):
    return sys.argv[0] + '?' + urllib.parse.urlencode(query)

def play_audio(url):
    li = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=li)

if __name__ == '__main__':
    addon_handle = int(sys.argv[1])
    args = urllib.parse.parse_qs(sys.argv[2][1:])

    if 'play' in args:
        play_audio(args['play'][0])
    else:
        url = args.get('url', [BASE_URL])[0]
        list_items(url)

