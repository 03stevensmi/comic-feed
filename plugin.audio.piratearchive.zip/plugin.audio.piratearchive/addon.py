import xbmc
import xbmcgui
import xbmcplugin
import requests
from bs4 import BeautifulSoup
import sys

BASE_URL = 'https://www.thepiratearchive.net/stations/'

def get_stations():
    response = requests.get(BASE_URL)
    soup = BeautifulSoup(response.content, 'html.parser')
    stations = []
    for link in soup.find_all('a'):
        url = link.get('href')
        if url and url.startswith(BASE_URL):
            title = link.text.strip()
            stations.append((title, url))
    return stations

def list_stations():
    stations = get_stations()
    for title, url in stations:
        li = xbmcgui.ListItem(label=title)
        li.setInfo('music', {'title': title})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def play_audio(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    audio_url = soup.find('audio')['src']
    li = xbmcgui.ListItem(path=audio_url)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=li)

if __name__ == '__main__':
    addon_handle = int(sys.argv[1])
    args = sys.argv[2][1:]

    if args:
        play_audio(args)
    else:
        list_stations()
